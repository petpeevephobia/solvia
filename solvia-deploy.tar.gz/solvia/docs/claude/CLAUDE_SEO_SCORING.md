# 📊 CLAUDE - SEO Scoring System Documentation

> **Purpose**: Document the unified SEO scoring algorithm used across Solvia
> **Status**: ✅ COMPLETE  
> **Implementation Date**: 2025-08-20
> **Version**: 1.0.0

---

## 🎯 Executive Summary

Solvia uses a **unified SEO scoring system** that provides consistent scoring across all components (GSC metrics, Audit Engine, Dashboard). The score ranges from 0-100 with a base score of 25 for sites with no data.

---

## 📐 Scoring Algorithm

### **Core Formula**

The SEO score is calculated using a weighted multi-factor approach:

```python
SEO Score = (Traffic × 30%) + (Position × 25%) + (CTR × 25%) + (Trends × 20%)
```

### **Component Weights**

| Component | Weight | Purpose |
|-----------|--------|---------|
| **Traffic** | 30% | Business value and revenue impact |
| **Position** | 25% | Search visibility potential |
| **CTR** | 25% | Content relevance and appeal |
| **Trends** | 20% | Growth momentum indicator |

---

## 🔢 Component Calculations

### **1. Traffic Score (0-100)**

Uses logarithmic scale to handle wide traffic ranges:

```python
if clicks > 0:
    score = log10(clicks + 1) × 20
    # Examples:
    # 10 clicks = 20 points
    # 100 clicks = 40 points
    # 1000 clicks = 60 points
    # 10000 clicks = 80 points
else:
    score = 0
```

### **2. Position Score (0-100)**

Better positions (lower numbers) get higher scores:

```python
if position <= 1:
    score = 100
elif position <= 10:
    score = 110 - (position × 10)
elif position <= 20:
    score = 20 - position
else:
    score = 0
```

| Position | Score |
|----------|-------|
| 1 | 100 |
| 3 | 80 |
| 5 | 60 |
| 10 | 10 |
| 15 | 5 |
| 20+ | 0 |

### **3. CTR Score (0-100)**

Compares actual CTR to industry benchmarks:

```python
expected_ctr = get_benchmark_for_position(position)
if expected_ctr > 0:
    score = (actual_ctr / expected_ctr) × 50
    # 100% of benchmark = 50 score
    # 200% of benchmark = 100 score
else:
    score = actual_ctr × 1000
    # 5% CTR = 50 score
    # 10% CTR = 100 score
```

#### **Industry CTR Benchmarks**

| Position | Expected CTR |
|----------|-------------|
| 1 | 28.5% |
| 2 | 15.7% |
| 3 | 9.4% |
| 4 | 6.2% |
| 5 | 5.0% |
| 6 | 3.8% |
| 7 | 3.0% |
| 8 | 2.4% |
| 9 | 2.0% |
| 10 | 2.5% |

### **4. Trend Score (0-100)**

Analyzes performance changes over time:

```python
base_score = 50  # Neutral starting point

# Traffic trend (±25 points)
if traffic_change > 20%:
    score += 25
elif traffic_change > 0%:
    score += 12
elif traffic_change < -20%:
    score -= 25
elif traffic_change < 0%:
    score -= 12

# Position trend (±25 points)
if position_improved > 2:
    score += 25
elif position_improved > 0:
    score += 12
elif position_worsened > 2:
    score -= 25
elif position_worsened > 0:
    score -= 12
```

---

## 🚨 Penalties

Critical issues apply multiplicative penalties:

| Condition | Penalty | Impact |
|-----------|---------|--------|
| **No impressions** | ×0.3 | 70% score reduction |
| **Zero CTR with impressions > 100** | ×0.5 | 50% score reduction |
| **Very low CTR (<0.1%) with impressions > 1000** | ×0.7 | 30% score reduction |

---

## 📊 Score Interpretations

| Score Range | Rating | Description | Recommendation |
|-------------|--------|-------------|----------------|
| **80-100** | Excellent | Outstanding SEO performance | Maintain strategy, explore new opportunities |
| **60-79** | Good | Performing well with room to improve | Focus on underperforming pages |
| **40-59** | Fair | Needs attention in several areas | Review and fix critical issues |
| **20-39** | Poor | Significant problems | Urgent action on visibility and content |
| **0-19** | Critical | Minimal or no search visibility | Check indexing, robots.txt, submit sitemap |

---

## 🔄 Edge Cases

### **No Data (0 clicks, 0 impressions, 0 position)**
- **Score**: 25.0
- **Reasoning**: Base score indicating site exists but has no visibility

### **Impressions Without Clicks**
- **Example**: 1000 impressions, 0 clicks
- **Score**: ~5-10 (heavily penalized)
- **Reasoning**: Visibility without engagement indicates poor relevance

### **New Sites**
- **First Month**: Scores typically 20-40
- **Growth Phase**: 40-60 after 3-6 months
- **Mature**: 60+ after optimization

---

## 🏗️ Implementation

### **Core Module**
```python
# app/core/seo_scoring.py
from app.core.seo_scoring import SEOScoringEngine

score = SEOScoringEngine.calculate_score(
    clicks=100,
    impressions=2000,
    ctr=0.05,
    position=5.5,
    historical_data={
        'clicks': 80,
        'position': 6.0
    }
)
```

### **Usage Locations**

1. **GSC Metrics** (`app/auth/google_oauth.py`)
   - Real-time score calculation
   - Empty metrics handling

2. **Audit Engine** (`app/audit/engine.py`)
   - Comprehensive analysis
   - Historical comparison

3. **Dashboard** (`app/static/dashboard.js`)
   - Display and interpretation
   - Trend visualization

---

## 🧪 Test Scenarios

### **Scenario 1: Zero Data**
```python
Input: clicks=0, impressions=0, ctr=0, position=0
Output: 25.0
```

### **Scenario 2: Low Performance**
```python
Input: clicks=10, impressions=1000, ctr=0.01, position=15
Output: ~15-20
```

### **Scenario 3: Average Performance**
```python
Input: clicks=100, impressions=2000, ctr=0.05, position=8
Output: ~45-55
```

### **Scenario 4: High Performance**
```python
Input: clicks=500, impressions=2000, ctr=0.25, position=3
Output: ~70-80
```

---

## 📈 Historical Context

### **Version History**

| Version | Date | Changes |
|---------|------|---------|
| 0.1.0 | 2025-08-15 | Initial simple formula |
| 0.2.0 | 2025-08-16 | Added weighted components |
| 1.0.0 | 2025-08-20 | Unified scoring system |

### **Previous Issues Fixed**

1. **Inconsistent Formulas**: Different components used different calculations
2. **Zero Data Handling**: Returned different base scores (0, 50, 100)
3. **No Penalties**: Failed to penalize critical issues
4. **Missing Trends**: Didn't account for momentum

---

## 🔮 Future Enhancements

### **Planned Improvements**

1. **Machine Learning Calibration**
   - Learn from user feedback
   - Auto-adjust weights based on industry

2. **Competitor Benchmarking**
   - Relative scoring vs competitors
   - Market share integration

3. **Seasonal Adjustments**
   - Account for seasonal traffic patterns
   - Holiday/event normalization

4. **Multi-Site Scoring**
   - Portfolio-level scoring
   - Cross-site comparisons

---

## 🎯 Business Impact

### **User Benefits**

- **Consistency**: Same score regardless of where it's viewed
- **Transparency**: Clear calculation methodology
- **Actionability**: Score directly relates to needed actions
- **Comparability**: Can track progress over time

### **Technical Benefits**

- **Maintainability**: Single source of truth
- **Testability**: Isolated, pure functions
- **Extensibility**: Easy to add new factors
- **Performance**: Optimized calculations

---

## 📚 References

- Advanced Web Ranking CTR Study (2024)
- Google Search Quality Guidelines
- Statistical Process Control in SEO (Academic Paper, 2023)
- Clean Architecture principles (Robert C. Martin)

---

**Module**: `app/core/seo_scoring.py`
**Tests**: `test_unified_scoring.py`
**Status**: Production Ready
**Performance**: < 1ms calculation time