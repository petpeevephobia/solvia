# CLAUDE_API.md - Solvia API Documentation

> **Base URL**: `http://localhost:8000`
> **Authentication**: Bearer JWT Token
> **API Version**: 1.1.0-alpha
> **Last Updated**: 2025-08-20

---

## 🔐 Authentication

### **Headers Required**
```http
Authorization: Bearer <jwt_token>
Content-Type: application/json
```

---

## 📚 API Endpoints

### **1. Authentication Endpoints**

#### **POST /auth/register**
Register new user account.

**Request Body:**
```json
{
  "email": "user@example.com",
  "password": "SecurePass123"
}
```

**Response (201):**
```json
{
  "id": "uuid",
  "email": "user@example.com",
  "message": "User registered successfully. Please check your email to verify your account.",
  "created_at": "2025-08-15T10:00:00Z"
}
```

---

#### **POST /auth/login**
Authenticate user and receive JWT token.

**Request Body:**
```json
{
  "email": "user@example.com",
  "password": "SecurePass123"
}
```

**Response (200):**
```json
{
  "access_token": "eyJhbGciOiJIUzI1NiIs...",
  "token_type": "bearer",
  "user": {
    "id": "uuid",
    "email": "user@example.com"
  }
}
```

---

#### **POST /auth/refresh-token**
Refresh expired JWT token.

**Headers:**
```http
Authorization: Bearer <expired_token>
```

**Response (200):**
```json
{
  "access_token": "eyJhbGciOiJIUzI1NiIs...",
  "token_type": "bearer",
  "expires_in": 1800
}
```

---

#### **GET /auth/me**
Get current user information.

**Response (200):**
```json
{
  "id": "uuid",
  "email": "user@example.com",
  "message": "User information retrieved successfully",
  "created_at": "2025-08-15T10:00:00Z"
}
```

---

#### **POST /auth/logout**
Logout current user.

**Response (200):**
```json
{
  "message": "Successfully logged out"
}
```

---

### **2. Google OAuth & Search Console**

#### **GET /auth/google/authorize**
Generate Google OAuth authorization URL.

**Query Parameters:**
- `email` (optional): Pre-fill email for OAuth

**Response (302):**
Redirects to Google OAuth consent screen

---

#### **GET /auth/google/callback**
Handle OAuth callback from Google.

**Query Parameters:**
- `code`: Authorization code from Google
- `state`: CSRF protection state
- `error` (optional): OAuth error message

**Response (302):**
Redirects to `/domain-selection` or `/property-selection`

---

#### **GET /auth/gsc/properties**
Get list of Google Search Console properties.

**Response (200):**
```json
{
  "properties": [
    {
      "siteUrl": "https://example.com",
      "permissionLevel": "siteOwner"
    },
    {
      "siteUrl": "sc-domain:example.com",
      "permissionLevel": "siteFullUser"
    }
  ],
  "message": "Properties retrieved successfully"
}
```

---

#### **POST /auth/gsc/select-property**
Select a GSC property for tracking.

**Request Body:**
```json
{
  "property_url": "https://example.com"
}
```

**Response (200):**
```json
{
  "success": true,
  "message": "Property https://example.com selected successfully"
}
```

---

#### **GET /auth/gsc/metrics**
Get Google Search Console metrics for selected property.

**Response (200):**
```json
{
  "success": true,
  "metrics": {
    "seo_score": 75.5,
    "organic_traffic": 15000,
    "clicks": 450,
    "ctr": 3.0,
    "avg_position": 12.5,
    "start_date": "2025-07-15",
    "end_date": "2025-08-15"
  },
  "website": "https://example.com"
}
```

---

#### **GET /auth/gsc/selected-website**
Get currently selected website.

**Response (200):**
```json
{
  "success": true,
  "selected_website": "https://example.com"
}
```

---

#### **GET /auth/gsc/keywords**
Get top performing keywords.

**Response (200):**
```json
{
  "keywords": [
    {
      "query": "seo tool",
      "clicks": 120,
      "impressions": 5000,
      "ctr": 2.4,
      "position": 8.5
    }
  ]
}
```

---

#### **POST /auth/gsc/refresh**
Force refresh of SEO metrics.

**Response (200):**
```json
{
  "success": true,
  "message": "SEO metrics refreshed successfully!",
  "metrics": {...}
}
```

---

### **3. Chat & AI System**

#### **POST /auth/chat/send**
Send message to Solvia AI assistant.

**Request Body:**
```json
{
  "message_content": "What's my SEO score?",
  "sender_name": "John"
}
```

**Response (200):**
```json
{
  "user_message_id": "msg_123",
  "ai_message_id": "msg_124",
  "ai_response": "Your current SEO score is 75.5/100...",
  "ai_responses": ["Your current SEO score is 75.5/100..."],
  "success": true
}
```

---

#### **GET /auth/chat/history**
Get chat conversation history.

**Query Parameters:**
- `limit` (optional, default: 50): Number of messages

**Response (200):**
```json
{
  "messages": [
    {
      "message_id": "msg_123",
      "message_content": "What's my SEO score?",
      "message_type": "user",
      "sender_name": "John",
      "created_at": "2025-08-15T10:00:00Z"
    },
    {
      "message_id": "msg_124",
      "message_content": "Your SEO score is 75.5/100",
      "message_type": "ai",
      "sender_name": "Solvia",
      "created_at": "2025-08-15T10:00:01Z"
    }
  ],
  "success": true
}
```

---

### **4. Dashboard & Analytics**

#### **GET /auth/dashboard**
Get complete dashboard data.

**Response (200):**
```json
{
  "user": {
    "id": "uuid",
    "email": "user@example.com",
    "is_verified": true,
    "created_at": "2025-08-15T10:00:00Z"
  },
  "metrics": {
    "seo_score": 75.5,
    "impressions": 15000,
    "clicks": 450,
    "ctr": 3.0,
    "avg_position": 12.5
  },
  "ai_insights": {
    "visibility_performance": {...},
    "analysis": {...}
  }
}
```

---

#### **GET /auth/dashboard/cache**
Get cached dashboard data.

**Response (200):**
```json
{
  "success": true,
  "has_cache": true,
  "data": {
    "metrics": {...},
    "ai_insights": {...},
    "keywords": [...]
  },
  "message": "Loaded latest cached dashboard data."
}
```

---

#### **POST /auth/dashboard/cache**
Store dashboard data in cache.

**Request Body:**
```json
{
  "dashboard_data": {
    "metrics": {...}
  },
  "ai_insights": {...},
  "keywords": [...]
}
```

**Response (200):**
```json
{
  "success": true,
  "message": "Dashboard data cached successfully!"
}
```

---

### **5. Website Content**

#### **POST /auth/website/content/fetch**
Fetch and analyze website content.

**Response (200):**
```json
{
  "success": true,
  "message": "Website content fetched and stored successfully!",
  "content": {
    "title_tags": {
      "default": "Example Site - SEO Tool"
    },
    "meta_descriptions": {
      "default": "Professional SEO audit tool..."
    },
    "page_content": {
      "main": "Main content text...",
      "headings": [
        {"tag": "h1", "text": "Welcome"},
        {"tag": "h2", "text": "Features"}
      ],
      "links": [
        {"text": "About", "href": "https://example.com/about"}
      ]
    }
  }
}
```

---

#### **GET /auth/website/content**
Get stored website content.

**Response (200):**
```json
{
  "success": true,
  "message": "Website content retrieved successfully!",
  "content": {...},
  "fetched_at": "2025-08-15T10:00:00Z"
}
```

---

### **6. Benchmark & Insights**

#### **GET /auth/benchmark/insights**
Get AI-generated SEO insights.

**Query Parameters:**
- `explicit_ai` (optional): Force regeneration if "true"

**Headers (optional):**
- `X-Explicit-AI-Request: true` - Force regeneration

**Response (200):**
```json
{
  "visibility_performance": {
    "overall_assessment": "Your website shows strong performance...",
    "metrics": {...}
  },
  "analysis": {
    "summary": "Based on the last 30 days of data..."
  }
}
```

---

### **7. Audit Engine Endpoints** ✅ NEW (2025-08-20)

#### **GET /audit/health**
Check audit engine health status.

**Response (200):**
```json
{
  "status": "healthy",
  "engine": "audit_engine_v1",
  "analyzers": ["performance", "anomaly", "trends", "opportunities"]
}
```

---

#### **POST /audit/trigger**
Start a new SEO audit for selected website.

**Request Body:**
```json
{
  "date_range_days": 30,
  "force_refresh": false,
  "include_recommendations": true
}
```

**Response (200):**
```json
{
  "audit_id": "audit_20250820_123456_user123",
  "status": "pending",
  "progress": 0,
  "message": "Audit initiated, starting analysis...",
  "estimated_completion": "2025-08-20T12:35:00Z"
}
```

---

#### **GET /audit/status/{audit_id}**
Check audit processing status.

**Response (200):**
```json
{
  "audit_id": "audit_20250820_123456_user123",
  "status": "completed",
  "progress": 100,
  "message": "Audit completed successfully",
  "estimated_completion": "2025-08-20T12:35:00Z"
}
```

---

#### **GET /audit/results/{audit_id}**
Get complete audit results.

**Response (200):**
```json
{
  "audit_id": "audit_20250820_123456_user123",
  "user_email": "user@example.com",
  "website_url": "https://example.com",
  "seo_score": 75.5,
  "previous_score": 72.0,
  "score_delta": 3.5,
  "metrics": {
    "total_clicks": 1250,
    "total_impressions": 45000,
    "average_ctr": 0.028,
    "average_position": 12.5,
    "total_queries": 850,
    "total_pages": 125
  },
  "issues": [
    {
      "issue_id": "uuid",
      "issue_type": "traffic_drop",
      "severity": "critical",
      "category": "performance",
      "title": "Significant Traffic Drop Detected",
      "description": "Traffic decreased by 35% in the last 30 days",
      "recommendation": "Review recent changes and check for technical issues",
      "traffic_impact": 35.0,
      "business_impact": "high"
    }
  ],
  "critical_issues": 1,
  "high_issues": 3,
  "medium_issues": 5,
  "low_issues": 8,
  "total_issues": 17,
  "traffic_change": -15.5,
  "position_change": 2.1,
  "ctr_change": -5.2,
  "audit_date": "2025-08-20T12:34:56Z",
  "processing_time_ms": 2563,
  "data_freshness": "real-time"
}
```

---

#### **GET /audit/latest**
Get the most recent audit for user's selected website.

**Response (200):**
Same as `/audit/results/{audit_id}`

---

#### **GET /audit/history**
Get paginated audit history.

**Query Parameters:**
- `limit` (optional, default: 10): Number of results
- `offset` (optional, default: 0): Pagination offset

**Response (200):**
```json
[
  {
    "audit_id": "audit_20250820_123456_user123",
    "audit_date": "2025-08-20T12:34:56Z",
    "seo_score": 75.5,
    "score_delta": 3.5,
    "total_issues": 17,
    "critical_issues": 1,
    "trend": "improved"
  }
]
```

---

#### **GET /audit/top-issues**
Get top critical issues for dashboard display.

**Query Parameters:**
- `severity` (optional): Filter by severity (critical/high/medium/low)
- `limit` (optional, default: 3): Number of issues

**Response (200):**
```json
{
  "website": "https://example.com",
  "audit_date": "2025-08-20T12:34:56Z",
  "seo_score": 75.5,
  "total_issues": 17,
  "top_issues": [
    {
      "issue_id": "uuid",
      "severity": "critical",
      "title": "Significant Traffic Drop",
      "description": "35% traffic decrease detected",
      "business_impact": "high",
      "traffic_impact": 35.0
    }
  ]
}
```

---

#### **POST /audit/export/{audit_id}**
Export audit results (JSON format, PDF planned).

**Query Parameters:**
- `format` (optional, default: "json"): Export format

**Response (200):**
```json
{
  // Complete audit results in JSON format
}
```

---

### **8. Utility Endpoints**

#### **GET /**
API root information.

**Response (200):**
```json
{
  "message": "Welcome to Solvia Authentication API",
  "version": "1.0.0",
  "docs": "/docs",
  "ui": "/ui",
  "dashboard": "/dashboard"
}
```

---

#### **GET /health**
Health check endpoint.

**Response (200):**
```json
{
  "status": "healthy",
  "service": "solvia-auth"
}
```

---

#### **GET /api/health**
API health check.

**Response (200):**
```json
{
  "status": "healthy",
  "service": "solvia-auth-api",
  "version": "1.0.0"
}
```

---

## 🎨 UI Routes (HTML Pages)

| Route | Description | Auth Required |
|-------|-------------|---------------|
| `/ui` | Login page | No |
| `/dashboard` | Main dashboard | Yes |
| `/domain-selection` | Domain selection | Yes |
| `/property-selection` | Property selection | Yes |
| `/setup` | Setup wizard | Yes |
| `/login` | Login redirect | No |

---

## 🔴 Error Responses

### **Standard Error Format**
```json
{
  "error": "Error message",
  "status_code": 400,
  "detail": "Detailed error description"
}
```

### **Common Status Codes**
- `200 OK` - Request successful
- `201 Created` - Resource created
- `302 Found` - Redirect
- `400 Bad Request` - Invalid request
- `401 Unauthorized` - Authentication required
- `403 Forbidden` - Access denied
- `404 Not Found` - Resource not found
- `500 Internal Server Error` - Server error

---

## 📊 Rate Limits

| Endpoint Category | Limit | Window |
|------------------|-------|--------|
| Authentication | 10 requests | 1 minute |
| GSC Metrics | 100 requests | 1 hour |
| Chat Messages | 50 requests | 1 minute |
| Dashboard | 30 requests | 1 minute |

---

## 🔄 Webhook Events (Future)

### **Planned Events**
- `user.registered` - New user signup
- `gsc.property.selected` - Property selection
- `metrics.updated` - Metrics refresh
- `audit.completed` - Audit generation

---

## 📝 API Testing

### **Postman Collection**
Available at: `/docs` (FastAPI automatic documentation)

### **Example cURL Commands**

**Login:**
```bash
curl -X POST http://localhost:8000/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"user@example.com","password":"Pass123"}'
```

**Get Metrics:**
```bash
curl -X GET http://localhost:8000/auth/gsc/metrics \
  -H "Authorization: Bearer <token>"
```

**Send Chat Message:**
```bash
curl -X POST http://localhost:8000/auth/chat/send \
  -H "Authorization: Bearer <token>" \
  -H "Content-Type: application/json" \
  -d '{"message_content":"Hello Solvia","sender_name":"User"}'
```

---

**API Version**: 1.0.0-alpha
**Total Endpoints**: 31
**Authentication**: JWT Bearer Token
**Documentation**: Auto-generated at `/docs`