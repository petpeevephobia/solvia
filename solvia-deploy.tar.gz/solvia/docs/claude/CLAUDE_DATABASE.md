# CLAUDE_DATABASE.md - Solvia Database Documentation

> **Database**: PostgreSQL (via Supabase)
> **ORM**: None (Raw SQL + Supabase Client)
> **Security**: Row Level Security (RLS)
> **Last Updated**: 2025-08-15

---

## 🗄️ Database Architecture

### **Infrastructure**
- **Provider**: Supabase (Managed PostgreSQL)
- **Version**: PostgreSQL 15.x
- **Region**: Auto-selected by Supabase
- **Backup**: Daily automated backups
- **Connection**: SSL enforced

### **Access Layers**
1. **Anon Key**: Public client access (RLS enforced)
2. **Service Role Key**: Admin bypass for RLS
3. **Direct Connection**: For migrations only

---

## 📊 Schema Overview

### **Tables Summary**
| Table | Purpose | Row Count | RLS |
|-------|---------|-----------|-----|
| `user_sessions` | User auth & profile | Variable | ✅ |
| `chat_messages` | AI conversations | Growing | ✅ |
| `gsc_connections` | OAuth credentials | 1 per user | ✅ |
| `gsc_metrics_cache` | Cached SEO data | Variable | ✅ |
| `user_websites` | Selected properties | 1 per user | ✅ |
| `website_content` | Scraped content | Variable | ✅ |

---

## 🔍 Detailed Table Schemas

### **1. user_sessions**
Stores user authentication and session data.

```sql
CREATE TABLE user_sessions (
    id SERIAL PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL,
    name VARCHAR(255),
    picture TEXT,
    access_token TEXT,
    refresh_token TEXT,
    selected_website TEXT,
    last_login TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);
```

**Indexes:**
- `idx_user_sessions_email` on `email`

**RLS Policies:**
- SELECT: Users can view their own session
- INSERT: Users can create their own session
- UPDATE: Users can update their own session

---

### **2. chat_messages**
Stores chat history between users and Solvia AI.

```sql
CREATE TABLE chat_messages (
    id SERIAL PRIMARY KEY,
    user_email VARCHAR(255) NOT NULL,
    message_content TEXT NOT NULL,
    message_type VARCHAR(50) NOT NULL, -- 'user' or 'ai'
    sender_name VARCHAR(100) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);
```

**Indexes:**
- `idx_chat_messages_user_email` on `user_email`
- `idx_chat_messages_created_at` on `created_at`

**Constraints:**
- `message_type` must be 'user' or 'ai'

---

### **3. gsc_connections**
Stores Google OAuth credentials for GSC access.

```sql
CREATE TABLE gsc_connections (
    id SERIAL PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL,
    access_token TEXT NOT NULL,
    refresh_token TEXT,
    expires_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);
```

**Security:**
- Tokens encrypted at rest
- Service role key required for initial storage
- Auto-update trigger for `updated_at`

---

### **4. gsc_metrics_cache**
Caches Google Search Console metrics for performance.

```sql
CREATE TABLE gsc_metrics_cache (
    id SERIAL PRIMARY KEY,
    user_email VARCHAR(255) NOT NULL,
    website_url TEXT NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    seo_score NUMERIC(5,2),      -- 0.00 to 100.00
    impressions INTEGER,
    clicks INTEGER,
    ctr NUMERIC(5,2),            -- Percentage
    avg_position NUMERIC(5,2),
    cache_date DATE NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);
```

**Indexes:**
- `idx_gsc_cache_user_email` on `user_email`
- `idx_gsc_cache_website_date` on `(website_url, cache_date)`

**Cache Strategy:**
- TTL: 24 hours
- Key: `(user_email, website_url, date_range)`

---

### **5. user_websites**
Stores user's selected GSC property.

```sql
CREATE TABLE user_websites (
    id SERIAL PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL,
    website_url TEXT NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);
```

**Business Rules:**
- One website per user (UNIQUE on email)
- URL format: `https://example.com` or `sc-domain:example.com`

---

### **6. website_content**
Stores scraped website content for analysis.

```sql
CREATE TABLE website_content (
    id SERIAL PRIMARY KEY,
    email VARCHAR(255) NOT NULL,
    website_url TEXT NOT NULL,
    title_tags JSONB,          -- {"default": "Page Title"}
    meta_descriptions JSONB,    -- {"default": "Description"}
    page_content JSONB,         -- Complex nested structure
    fetched_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);
```

**JSONB Structure:**
```json
{
    "page_content": {
        "main": "Main content text...",
        "headings": [
            {"tag": "h1", "text": "Title"},
            {"tag": "h2", "text": "Subtitle"}
        ],
        "links": [
            {"text": "Link text", "href": "URL"}
        ],
        "page_title": "Full page title",
        "meta_description": "Meta description"
    }
}
```

---

## 🔒 Row Level Security (RLS)

### **Policy Pattern**
All tables follow the same RLS pattern:

```sql
-- Enable RLS
ALTER TABLE table_name ENABLE ROW LEVEL SECURITY;

-- SELECT Policy
CREATE POLICY "Users can view own data" ON table_name
    FOR SELECT USING (auth.jwt() ->> 'email' = user_email_column);

-- INSERT Policy
CREATE POLICY "Users can insert own data" ON table_name
    FOR INSERT WITH CHECK (auth.jwt() ->> 'email' = user_email_column);

-- UPDATE Policy
CREATE POLICY "Users can update own data" ON table_name
    FOR UPDATE USING (auth.jwt() ->> 'email' = user_email_column);
```

### **RLS Bypass**
Service role key bypasses RLS for:
- OAuth credential storage
- Admin operations
- Background jobs

---

## 🔄 Database Triggers

### **1. Auto-Update Timestamp**
```sql
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Applied to tables with updated_at column
CREATE TRIGGER update_[table]_updated_at 
    BEFORE UPDATE ON [table_name]
    FOR EACH ROW 
    EXECUTE FUNCTION update_updated_at_column();
```

**Tables with trigger:**
- `user_sessions`
- `gsc_connections`
- `user_websites`

---

## 📈 Database Views

### **user_dashboard_data**
Aggregated view for dashboard performance.

```sql
CREATE OR REPLACE VIEW user_dashboard_data AS
SELECT 
    us.email,
    us.name,
    us.selected_website,
    us.last_login,
    COUNT(cm.id) as total_messages,
    MAX(cm.created_at) as last_message_at
FROM user_sessions us
LEFT JOIN chat_messages cm ON us.email = cm.user_email
GROUP BY us.email, us.name, us.selected_website, us.last_login;
```

---

## 🚀 Query Patterns

### **Common Queries**

#### **Get User Session**
```python
response = supabase.table('user_sessions')
    .select('*')
    .eq('email', user_email)
    .single()
    .execute()
```

#### **Store Chat Message**
```python
message_data = {
    'user_email': email,
    'message_content': content,
    'message_type': 'user',
    'sender_name': name
}
response = supabase.table('chat_messages')
    .insert(message_data)
    .execute()
```

#### **Check Cache**
```python
response = supabase.table('gsc_metrics_cache')
    .select('*')
    .eq('user_email', email)
    .eq('website_url', url)
    .gte('cache_date', today)
    .single()
    .execute()
```

#### **Upsert Website**
```python
website_data = {
    'email': user_email,
    'website_url': url
}
response = supabase.table('user_websites')
    .upsert(website_data, on_conflict=['email'])
    .execute()
```

---

## 📊 Performance Optimization

### **Indexes Strategy**
- **Primary Keys**: Auto-indexed
- **Foreign Keys**: Email columns indexed
- **Timestamp Columns**: Created_at indexed for sorting
- **Composite**: (website_url, cache_date) for cache lookups

### **Query Performance**
| Query Type | Average Time | Optimization |
|------------|--------------|--------------|
| User lookup | < 10ms | Email index |
| Cache check | < 20ms | Composite index |
| Chat history | < 50ms | Created_at index |
| Metrics fetch | < 100ms | Cached results |

---

## 🔧 Database Operations

### **Backup Strategy**
- **Automatic**: Daily backups by Supabase
- **Retention**: 7 days (free tier)
- **Point-in-time**: Available on Pro plan

### **Migration Process**
```bash
# Run migrations
psql $DATABASE_URL < setup_supabase.sql

# Verify tables
SELECT table_name FROM information_schema.tables 
WHERE table_schema = 'public';
```

### **Data Cleanup**
```sql
-- Clean old cache entries
DELETE FROM gsc_metrics_cache 
WHERE cache_date < CURRENT_DATE - INTERVAL '90 days';

-- Archive old chat messages
DELETE FROM chat_messages 
WHERE created_at < CURRENT_DATE - INTERVAL '180 days';
```

---

## 📈 Database Metrics

### **Storage Usage**
```sql
SELECT 
    schemaname,
    tablename,
    pg_size_pretty(pg_total_relation_size(schemaname||'.'||tablename)) AS size
FROM pg_tables 
WHERE schemaname = 'public'
ORDER BY pg_total_relation_size(schemaname||'.'||tablename) DESC;
```

### **Row Counts**
```sql
SELECT 
    'user_sessions' as table_name, COUNT(*) as count FROM user_sessions
UNION ALL
SELECT 'chat_messages', COUNT(*) FROM chat_messages
UNION ALL
SELECT 'gsc_connections', COUNT(*) FROM gsc_connections
-- etc...
```

---

## 🚨 Database Monitoring

### **Key Metrics to Track**
1. **Connection Pool**: Max 100 concurrent
2. **Query Time**: Alert if > 1 second
3. **Storage**: Alert at 80% capacity
4. **Cache Hit Rate**: Target > 70%
5. **RLS Violations**: Log and alert

### **Health Checks**
```python
async def check_database_health():
    try:
        # Test connection
        result = supabase.table('user_sessions').select('count').execute()
        
        # Check response time
        if response_time > 1000:  # ms
            alert("Database slow response")
        
        return {"status": "healthy", "response_time": response_time}
    except Exception as e:
        return {"status": "unhealthy", "error": str(e)}
```

---

## 🔄 Future Database Improvements

### **Planned Changes**
1. **Partitioning**: For chat_messages by month
2. **Read Replicas**: For scaling reads
3. **Materialized Views**: For complex aggregations
4. **Full-text Search**: For chat history
5. **Time-series Table**: For detailed metrics

### **Schema Evolution**
- Add `audit_logs` table
- Add `user_preferences` table
- Add `report_history` table
- Add `team_members` table (multi-user)

---

## 📝 Database Maintenance

### **Regular Tasks**
- [ ] Weekly: Check slow queries
- [ ] Monthly: Review index usage
- [ ] Monthly: Clean old cache entries
- [ ] Quarterly: Analyze table statistics
- [ ] Yearly: Archive old data

### **Emergency Procedures**
1. **Connection exhaustion**: Increase pool size
2. **Slow queries**: Add missing indexes
3. **Storage full**: Clean cache tables
4. **RLS bypass needed**: Use service role key

---

**Database Version**: PostgreSQL 15.x
**Total Tables**: 6 + 1 view
**Total Indexes**: 11
**RLS Policies**: 18
**Next Review**: Post-Alpha optimization