# CLAUDE_ARCHITECTURE.md - Solvia System Architecture

> **Project**: Solvia Alpha - SEO Audit Platform
> **Tech Stack**: Python/FastAPI + Supabase + Google OAuth/GSC API
> **Architecture Pattern**: Monolithic with Service Layer
> **Last Updated**: 2025-08-15

---

## 📁 Project Structure (44 Files Total)

```
solvia/
├── app/                          # Main application directory
│   ├── main.py                  # FastAPI app entry point & routing
│   ├── config.py                # Settings & environment configuration
│   ├── database.py              # Legacy database connections
│   │
│   ├── auth/                    # Authentication module
│   │   ├── routes.py            # Auth endpoints (1465 lines)
│   │   ├── google_oauth.py      # Google OAuth & GSC integration
│   │   ├── models.py            # Pydantic models for auth
│   │   ├── utils.py             # JWT, password hashing utilities
│   │   ├── benchmark_analyzer.py # SEO benchmark analysis
│   │   └── prompts/             # AI prompt templates
│   │
│   ├── ai/                      # AI agent system
│   │   └── agent_instructions.py # Solvia AI personality & rules
│   │
│   ├── database/                # Database layer
│   │   ├── supabase_db.py      # Supabase auth & data operations
│   │   └── supabase_client.py  # Client initialization
│   │
│   └── static/                  # Frontend assets (16 files)
│       ├── dashboard.html       # Main dashboard UI
│       ├── dashboard.js         # Dashboard logic
│       ├── dashboard.css        # Dashboard styles
│       ├── domain-selection.html/js/css
│       ├── property_selection.html
│       ├── setup_wizard.html
│       ├── index.html           # Login page
│       ├── auth.js              # Auth frontend logic
│       └── js/sidemenu.js      # Navigation
│
├── core/                        # Core business logic
│   ├── main.py                  # Legacy core entry
│   ├── auth_setup.py            # Auth configuration
│   ├── analysis_processor.py   # SEO analysis engine
│   └── modules/
│       └── prompt_loader.py    # Prompt template loader
│
├── setup_supabase.sql          # Database schema (224 lines)
├── requirements.txt            # Python dependencies
├── CLAUDE.md                   # Project memory
└── .env                        # Environment variables
```

---

## 🏗️ System Architecture

### **1. Request Flow**

```
User Browser → FastAPI Server → Route Handler → Service Layer → Database/API
                     ↓                ↓              ↓            ↓
              Static Files      Auth Check     Business Logic  Supabase/GSC
```

### **2. Core Components**

#### **FastAPI Application (`app/main.py`)**
- **Entry Point**: Initializes FastAPI app with CORS, static files
- **Routers**: Includes auth router from `auth/routes.py`
- **Static Routes**: `/ui`, `/dashboard`, `/domain-selection`, `/property-selection`
- **Health Check**: `/health` endpoint for monitoring

#### **Authentication System (`app/auth/`)**
- **OAuth Flow**: Google OAuth2 with GSC scopes
- **JWT Management**: Token creation, validation, refresh
- **User Sessions**: Stored in Supabase with RLS
- **Credentials Storage**: OAuth tokens cached & persisted

#### **Google Search Console Integration**
- **OAuth Handler**: `GoogleOAuthHandler` class
- **GSC Fetcher**: `GSCDataFetcher` for metrics retrieval
- **Caching Strategy**: 
  - Default 30-day range cached daily
  - Custom date ranges fetch fresh data
  - Cache stored in `gsc_metrics_cache` table

#### **AI Agent System**
- **Solvia Agent**: Main AI assistant for SEO insights
- **OpenAI Integration**: GPT-4o-mini model
- **Context Management**: Chat history + GSC metrics
- **Response Processing**: Markdown to HTML conversion

#### **Database Layer (Supabase)**
- **Auth**: Built-in Supabase Auth for user management
- **RLS**: Row Level Security on all tables
- **Tables**: 6 main tables + 1 view
- **Triggers**: Auto-update timestamps

---

## 🔄 Data Flow Patterns

### **1. Authentication Flow**
```
1. User clicks "Sign in with Google"
2. Redirect to Google OAuth → Authorize GSC access
3. Callback with code → Exchange for tokens
4. Store credentials in Supabase
5. Generate JWT → Return to client
6. Client stores JWT for API calls
```

### **2. GSC Metrics Flow**
```
1. Check cache (gsc_metrics_cache table)
2. If cache miss or expired:
   - Retrieve OAuth credentials
   - Call GSC API with date range
   - Calculate SEO score
   - Store in cache
3. Return metrics to client
```

### **3. AI Chat Flow**
```
1. User sends message
2. Store in chat_messages table
3. Get chat history (last 10 messages)
4. Fetch current GSC metrics
5. Build context for OpenAI
6. Generate response with GPT-4o-mini
7. Store AI response
8. Return formatted response
```

---

## 🔐 Security Architecture

### **Authentication Layers**
1. **Supabase Auth**: Primary user authentication
2. **JWT Tokens**: Stateless session management
3. **OAuth Tokens**: Google API access (encrypted storage)
4. **RLS Policies**: Database-level access control

### **API Security**
- **CORS**: Configured for production domains
- **HTTPBearer**: JWT validation on protected routes
- **Service Role Key**: Admin operations bypass RLS
- **Token Refresh**: Automatic token renewal

---

## 📊 Database Schema Overview

### **Core Tables**
1. **user_sessions**: User auth & profile data
2. **chat_messages**: AI conversation history
3. **gsc_connections**: Google OAuth credentials
4. **gsc_metrics_cache**: Cached SEO metrics
5. **user_websites**: Selected GSC properties
6. **website_content**: Scraped website data

### **Relationships**
- All tables linked by `email` (user identifier)
- RLS ensures users only access own data
- Indexes on email, dates for performance

---

## 🚀 Deployment Architecture

### **Environment Variables**
```env
SUPABASE_URL          # Supabase project URL
SUPABASE_KEY          # Anon key for client
SUPABASE_SERVICE_ROLE_KEY  # Admin access
GOOGLE_CLIENT_ID      # OAuth client ID
GOOGLE_CLIENT_SECRET  # OAuth secret
GOOGLE_REDIRECT_URI   # OAuth callback URL
OPENAI_API_KEY       # GPT-4o-mini access
JWT_SECRET_KEY       # Token signing
```

### **Server Requirements**
- Python 3.11+
- Uvicorn ASGI server
- PostgreSQL (via Supabase)
- 2GB RAM minimum
- HTTPS required for OAuth

---

## 🔧 Key Design Decisions

1. **Monolithic Architecture**: Simpler deployment for Alpha
2. **Supabase vs Custom DB**: Managed PostgreSQL with built-in auth
3. **RLS vs Application-level**: Database-enforced security
4. **Cache Strategy**: Balance API quotas vs freshness
5. **JWT vs Sessions**: Stateless for scalability
6. **Service Role Key**: Required for OAuth flow without JWT

---

## 📈 Performance Considerations

- **GSC API Quotas**: 1200 queries/day limit
- **Cache TTL**: 24 hours for default metrics
- **Query Optimization**: Indexes on frequent lookups
- **Response Time**: < 3s target for all endpoints
- **Concurrent Users**: ~100 with current architecture

---

## 🔄 Future Architecture Evolution

### **Phase 2 (Beta)**
- Separate workers for PDF generation
- Redis cache layer
- WebSocket for real-time updates

### **Phase 3 (Production)**
- Microservices separation
- Queue-based audit processing
- CDN for static assets
- Multi-region deployment

---

**Architecture Status**: Production-ready for Alpha launch
**Scalability Limit**: ~1000 users with current setup
**Next Review**: Post-Alpha feedback integration