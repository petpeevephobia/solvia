# CLAUDE_FRONTEND.md - Solvia Frontend Documentation

> **Framework**: Vanilla JavaScript (No framework)
> **Styling**: Custom CSS
> **Build**: Static files served by FastAPI
> **Last Updated**: 2025-08-15

---

## 🎨 Frontend Architecture

### **Technology Stack**
- **HTML5**: Semantic markup
- **CSS3**: Custom styles, Flexbox/Grid
- **JavaScript**: ES6+, Fetch API
- **No Dependencies**: Zero npm packages

### **File Structure**
```
app/static/
├── index.html                 # Login page
├── dashboard.html             # Main dashboard
├── dashboard.js               # Dashboard logic
├── dashboard.css              # Dashboard styles
├── domain-selection.html      # Domain picker
├── domain-selection.js        # Domain logic
├── domain-selection.css       # Domain styles
├── property_selection.html    # GSC property selector
├── setup_wizard.html          # Initial setup
├── settings.css               # Settings styles
├── style.css                  # Global styles
├── auth.js                    # Authentication logic
└── js/
    └── sidemenu.js           # Navigation menu
```

---

## 📱 Page Components

### **1. Login Page (`index.html`)**

#### **Features**
- Google OAuth sign-in button
- Email/password form (hidden by default)
- Responsive design
- Error message display

#### **Key Elements**
```html
<!-- Google Sign-in Button -->
<button class="google-signin-btn" onclick="signInWithGoogle()">
    <img src="google-icon.svg" alt="Google">
    Sign in with Google
</button>
```

#### **JavaScript Functions**
```javascript
function signInWithGoogle() {
    window.location.href = '/auth/google/authorize';
}
```

---

### **2. Dashboard (`dashboard.html`)**

#### **Layout Structure**
```html
<div class="dashboard-container">
    <div class="welcome-section" id="welcomeMessage"></div>
    <div class="overview-section">
        <div class="metrics-grid">
            <!-- Metric cards -->
        </div>
    </div>
</div>
```

#### **Metric Cards**
1. **SEO Score** - 0-100 scale with trend
2. **Average CTR** - Click-through rate
3. **Impressions** - Total search impressions
4. **Avg Position** - Keyword ranking

#### **Data Flow**
```javascript
// dashboard.js key functions
async function loadDashboard() {
    const metrics = await fetchMetrics();
    updateMetricCards(metrics);
    displayWelcomeMessage(userEmail);
}

async function fetchMetrics() {
    const response = await fetch('/auth/gsc/metrics', {
        headers: {
            'Authorization': `Bearer ${token}`
        }
    });
    return response.json();
}
```

---

### **3. Domain Selection (`domain-selection.html`)**

#### **User Flow**
1. Display available GSC properties
2. User selects primary domain
3. Store selection in database
4. Redirect to dashboard

#### **API Integration**
```javascript
async function loadProperties() {
    const response = await fetch('/auth/gsc/properties', {
        headers: { 'Authorization': `Bearer ${token}` }
    });
    const data = await response.json();
    displayProperties(data.properties);
}

async function selectProperty(siteUrl) {
    await fetch('/auth/gsc/select-property', {
        method: 'POST',
        headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ property_url: siteUrl })
    });
    window.location.href = '/dashboard';
}
```

---

## 🎨 Styling System

### **Design Tokens**
```css
:root {
    /* Colors */
    --primary-color: #4F46E5;
    --secondary-color: #10B981;
    --danger-color: #EF4444;
    --bg-primary: #FFFFFF;
    --bg-secondary: #F9FAFB;
    --text-primary: #111827;
    --text-secondary: #6B7280;
    
    /* Spacing */
    --spacing-xs: 0.25rem;
    --spacing-sm: 0.5rem;
    --spacing-md: 1rem;
    --spacing-lg: 1.5rem;
    --spacing-xl: 2rem;
    
    /* Typography */
    --font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
    --font-size-sm: 0.875rem;
    --font-size-base: 1rem;
    --font-size-lg: 1.125rem;
    --font-size-xl: 1.5rem;
}
```

### **Component Styles**

#### **Metric Card**
```css
.metric-card {
    background: var(--bg-primary);
    border-radius: 0.75rem;
    padding: 1.5rem;
    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
    transition: transform 0.2s;
}

.metric-card:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

.metric-value {
    font-size: 2rem;
    font-weight: 700;
    color: var(--text-primary);
}

.metric-change.positive {
    color: var(--secondary-color);
}

.metric-change.negative {
    color: var(--danger-color);
}
```

---

## 🔧 JavaScript Utilities

### **1. Token Management**
```javascript
// auth.js
const TokenManager = {
    get: () => localStorage.getItem('access_token'),
    set: (token) => localStorage.setItem('access_token', token),
    remove: () => localStorage.removeItem('access_token'),
    
    isValid: () => {
        const token = TokenManager.get();
        if (!token) return false;
        
        try {
            const payload = JSON.parse(atob(token.split('.')[1]));
            return payload.exp > Date.now() / 1000;
        } catch {
            return false;
        }
    }
};
```

### **2. API Client**
```javascript
class APIClient {
    constructor(baseURL = '') {
        this.baseURL = baseURL;
    }
    
    async request(endpoint, options = {}) {
        const token = TokenManager.get();
        
        const config = {
            ...options,
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`,
                ...options.headers
            }
        };
        
        const response = await fetch(`${this.baseURL}${endpoint}`, config);
        
        if (response.status === 401) {
            // Token expired, redirect to login
            window.location.href = '/login';
            return;
        }
        
        if (!response.ok) {
            throw new Error(`API Error: ${response.status}`);
        }
        
        return response.json();
    }
}

const api = new APIClient('/auth');
```

### **3. UI Helpers**
```javascript
// Loading states
function showLoading(elementId) {
    const element = document.getElementById(elementId);
    element.innerHTML = '<div class="spinner"></div>';
}

// Error handling
function showError(message) {
    const errorDiv = document.createElement('div');
    errorDiv.className = 'error-message';
    errorDiv.textContent = message;
    document.body.appendChild(errorDiv);
    
    setTimeout(() => errorDiv.remove(), 5000);
}

// Number formatting
function formatNumber(num) {
    if (num >= 1000000) {
        return (num / 1000000).toFixed(1) + 'M';
    } else if (num >= 1000) {
        return (num / 1000).toFixed(1) + 'K';
    }
    return num.toString();
}

// Percentage formatting
function formatPercentage(value) {
    return `${value.toFixed(1)}%`;
}
```

---

## 📊 Data Visualization

### **Metric Display Logic**
```javascript
function updateMetricCard(cardId, value, change) {
    const card = document.getElementById(cardId);
    const valueElement = card.querySelector('.metric-value');
    const changeElement = card.querySelector('.metric-change');
    
    // Update value
    valueElement.textContent = formatMetricValue(cardId, value);
    
    // Update change indicator
    if (change !== null) {
        const isPositive = change >= 0;
        changeElement.className = `metric-change ${isPositive ? 'positive' : 'negative'}`;
        changeElement.textContent = `${isPositive ? '↑' : '↓'} ${Math.abs(change)}%`;
    }
}

function formatMetricValue(metricType, value) {
    switch(metricType) {
        case 'seoScore':
            return `${value}/100`;
        case 'ctr':
        case 'avgPosition':
            return formatPercentage(value);
        case 'impressions':
            return formatNumber(value);
        default:
            return value;
    }
}
```

---

## 🔄 State Management

### **Application State**
```javascript
const AppState = {
    user: null,
    metrics: null,
    selectedWebsite: null,
    chatHistory: [],
    
    init() {
        this.loadFromStorage();
    },
    
    loadFromStorage() {
        this.user = JSON.parse(localStorage.getItem('user') || 'null');
        this.selectedWebsite = localStorage.getItem('selected_website');
    },
    
    saveToStorage() {
        localStorage.setItem('user', JSON.stringify(this.user));
        localStorage.setItem('selected_website', this.selectedWebsite);
    },
    
    updateMetrics(metrics) {
        this.metrics = metrics;
        this.lastUpdated = new Date();
    }
};
```

---

## 🚀 Performance Optimizations

### **1. Lazy Loading**
```javascript
// Load non-critical resources after page load
window.addEventListener('load', () => {
    // Load chat history
    loadChatHistory();
    
    // Preload next likely navigation
    prefetchDashboardData();
});
```

### **2. Debouncing**
```javascript
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Usage
const searchInput = document.getElementById('search');
searchInput.addEventListener('input', debounce(handleSearch, 300));
```

### **3. Caching**
```javascript
const CacheManager = {
    cache: new Map(),
    
    get(key) {
        const cached = this.cache.get(key);
        if (cached && Date.now() - cached.timestamp < 300000) { // 5 min
            return cached.data;
        }
        return null;
    },
    
    set(key, data) {
        this.cache.set(key, {
            data,
            timestamp: Date.now()
        });
    }
};
```

---

## 📱 Responsive Design

### **Breakpoints**
```css
/* Mobile First Approach */
/* Base styles for mobile */

/* Tablet */
@media (min-width: 768px) {
    .metrics-grid {
        grid-template-columns: repeat(2, 1fr);
    }
}

/* Desktop */
@media (min-width: 1024px) {
    .metrics-grid {
        grid-template-columns: repeat(4, 1fr);
    }
}

/* Large Desktop */
@media (min-width: 1440px) {
    .dashboard-container {
        max-width: 1280px;
        margin: 0 auto;
    }
}
```

---

## 🐛 Error Handling

### **Global Error Handler**
```javascript
window.addEventListener('unhandledrejection', event => {
    console.error('Unhandled promise rejection:', event.reason);
    showError('An unexpected error occurred. Please try again.');
});

window.addEventListener('error', event => {
    console.error('Global error:', event.error);
    if (event.error?.status === 401) {
        // Redirect to login on auth error
        window.location.href = '/login';
    }
});
```

---

## 🧪 Frontend Testing Checklist

### **Functionality Tests**
- [ ] OAuth login flow
- [ ] Token refresh mechanism
- [ ] Dashboard data loading
- [ ] Property selection
- [ ] Chat message sending
- [ ] Metric updates
- [ ] Error message display

### **Cross-Browser Testing**
- [ ] Chrome (latest)
- [ ] Firefox (latest)
- [ ] Safari (latest)
- [ ] Edge (latest)
- [ ] Mobile Safari
- [ ] Chrome Mobile

### **Performance Metrics**
- First Contentful Paint: < 1.5s
- Time to Interactive: < 3s
- Total Bundle Size: < 100KB
- API Response Time: < 500ms

---

## 🚦 Known Issues & Limitations

### **Current Limitations**
1. No offline support
2. Limited browser caching
3. No service worker
4. Basic error messages
5. No accessibility features (ARIA)

### **Planned Improvements**
- Progressive Web App (PWA)
- Service worker for offline
- Improved accessibility
- Dark mode support
- Animation library integration

---

**Frontend Version**: 1.0.0-alpha
**Browser Support**: Modern browsers (ES6+)
**Mobile Support**: Responsive design
**Next Update**: Post-Alpha feedback