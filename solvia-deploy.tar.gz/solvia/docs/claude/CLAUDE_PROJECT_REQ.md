Project Title: Solvia Alpha

Prepared by: @Nadra 

Date: 14 August 2025

---

---

## 1. Purpose

To provide a minimal yet powerful SEO audit tool that surfaces only the most critical issues impacting a website’s organic traffic. This tool is designed to connect directly to Google Search Console (GSC) to pull real, authenticated user data and run a deterministic audit that calculates an SEO score and highlights vital performance metrics.

The Alpha version aims to eliminate complexity and avoid overwhelming the user with excessive data, instead offering a single view of their SEO health and actionable issues they can understand without prior SEO knowledge. The product focuses solely on auditing capabilities for Alpha, deferring recommendation and implementation features to later stages of development.

## 2. Goals & Objectives

The primary goal is to ship a fully functional, stable end-to-end SEO audit experience. This involves three core objectives:

1. **Ensure reliable GSC integration** so that every user can connect their property and retrieve accurate historical and current performance data without manual intervention. The audit must use this stored data exclusively, avoiding AI-generated assumptions or placeholders.
2. **Present an actionable SEO snapshot** by calculating a single SEO score derived from key metrics such as organic traffic, average keyword position, CTR, and backlinks (with backlinks being a placeholder in Alpha). This score should be transparent and backed by verifiable data sources.
3. **Highlight the top 1–3 most critical SEO issues** directly on the home page with clear severity levels and data-driven explanations. These issues should be prioritized based on potential business impact, making it immediately clear where the user should focus their attention.

## 3. Target Users

The target users for Solvia Alpha are early-stage startup founders, small business owners, and marketing generalists who do not have deep SEO expertise but need to improve their online visibility. These users often lack the time and resources to engage with complex SEO dashboards and want quick, trustworthy insights they can act on immediately.

Secondary users include small marketing agencies that manage multiple client sites and require a streamlined way to identify SEO risks without deep manual analysis. The common denominator among target users is a need for automation, simplicity, and clarity.

## 4. Key Features

- **Google Search Console Integration**
    - OAuth2-based connection to GSC for secure authentication.
    - Caching and automatic retrieval of daily page and query-level performance data; number of clicks, impressions, CTR, and average position.
    - Storage of retrieved data in Supabase with Row Level Security (RLS) to ensure per-user data isolation.
- **Audit Engine**
    - Calculation of an SEO score based on normalised metrics from GSC.
    - Analysis of 30-day trends to identify drops in ranking, CTR decreases despite impression growth, and keyword loss.
    - Severity classification for each finding (High, Medium, Low) with supporting metrics and date ranges.
- **Home Page SEO Snapshot**
    - Display of four main data points: SEO Score, Organic Traffic (with 30-day change), Average Keyword Position, and Backlinks (placeholder).
    - “Critical Issues” section showing the top 1–2 most urgent findings with an option to view the full audit.
- **Solvia Agent**
    - Allows the user to initiate a full SEO audit on demand.
    - On request, retrieves the latest stored GSC data, runs it through the audit engine, and generates two outputs:
        1. **PDF Report** – A professionally formatted document containing the SEO score, key findings, and data-driven recommendations. Automatically sent to the user’s registered email address.
        2. **JSON Data File** – The raw audit data saved to the user’s account in Supabase. Accessible through a dedicated “Audit History” page for future reference and comparison.
    - Ensures that both outputs are generated in under 60 seconds for responsive UX.
    - PDF reports are branded with Solvia Alpha visuals, include timestamp and audit run ID, and show clear sections for metrics, findings, and recommended next steps.
- **Audit History**
    - Stores all JSON audit files in a dedicated Supabase table linked to the user ID.
    - Displays previous audits with SEO score deltas and timestamps.
    - Allows users to download past PDF reports directly from the interface.

## 5. Non-Functional Requirements

Uptime: 99.9% availability

Security: GDPR & PDPA-compliant, secure payment

Performance: App should load in under 3s on 4G

## 6. Suggested Technology Stack

**Backend:**

- Python 3.11+ with FastAPI
- Uvicorn as ASGI server
- Pydantic for data validation
- Google OAuth2 for authentication
- Google Search Console API v1
- OpenAI GPT-4o-mini for AI responses
- Supabase (PostgreSQL) with Row Level Security

**Frontend:**

- Static HTML/CSS/JavaScript
- Fetch-based API calls
- No framework dependencies

**Dependencies:**

- fastapi==0.104.1
- uvicorn[standard]==0.24.0
- supabase==2.0.2
- google-auth==2.23.4
- google-auth-oauthlib==1.1.0
- google-api-python-client==2.108.0
- openai>=1.0.0
- markdown>=3.0.0

## 7. Timeline (Alpha)

- **15–20 August 2025: Data Pipeline** – Build the OAuth connection flow, retrieve GSC data, store it in Supabase with RLS, and ensure queries for snapshots return in under 300ms.
- **20–25 August 2025: Audit Engine** – Implement SEO score calculation, anomaly detection rules, and severity classification with persisted audit results.
- **25–29 August 2025: Solvia Agent** – Create an API endpoint that generates an audit summary using only structured audit data, and integrate the agent’s summary into the home page.
- **1–3 September 2025: Critical Issues Section** – Implement a home page component that displays the top 1–2 audit findings by severity, linked to the full audit details.
- **3–9 September 2025: QA & Alpha Launch** – Test OAuth flows, audit accuracy, and UI responsiveness; release Alpha to a limited group of early testers.

## 8. Risks & Considerations

- **Google API Quotas**: Exceeding GSC API limits could disrupt data retrieval. This will be mitigated by caching results, using pagination for large datasets, and implementing request throttling.
- **OAuth Redirect URI Mismatch**: Improper configuration of authorized redirect URIs could block authentication. The exact redirect URIs must be matched and tested before deployment.
- **Data Accuracy**: AI summaries could deviate from actual data if not constrained. This will be mitigated by strictly passing structured JSON and forbidding AI from making assumptions.
- **Security & Privacy**: Leaked service role keys or insufficient RLS enforcement could compromise user data. This will be mitigated by keeping all sensitive keys server-only and enabling strict RLS policies.
- **Performance on Large Properties**: Sites with high query or page counts could cause slow queries. Indexes and materialized views will be used to keep performance stable.
- **User Trust**: Incorrect or unverifiable metrics could damage credibility. Every reported metric will include a tooltip showing its exact data source and date range.

## 9. Appendices

### **9.1 Data Model**

The actual database schema includes:

**`user_sessions` table:**

- `id` (SERIAL PRIMARY KEY)
- `email` (VARCHAR(255) UNIQUE NOT NULL)
- `name` (VARCHAR(255))
- `picture` (TEXT)
- `access_token` (TEXT)
- `refresh_token` (TEXT)
- `selected_website` (TEXT)
- `last_login` (TIMESTAMP WITH TIME ZONE)
- `created_at` (TIMESTAMP WITH TIME ZONE)
- `updated_at` (TIMESTAMP WITH TIME ZONE)

**`chat_messages` table:**

- `id` (SERIAL PRIMARY KEY)
- `user_email` (VARCHAR(255) NOT NULL)
- `message_content` (TEXT NOT NULL)
- `message_type` (VARCHAR(50) NOT NULL) - "user" or "ai"
- `sender_name` (VARCHAR(100) NOT NULL)
- `created_at` (TIMESTAMP WITH TIME ZONE)

**`gsc_metrics_cache` table** (referenced in code but not in setup_supabase.sql):

- `user_email` (VARCHAR(255))
- `website_url` (TEXT)
- `start_date` (DATE)
- `end_date` (DATE)
- `seo_score` (NUMERIC)
- `impressions` (INTEGER)
- `clicks` (INTEGER)
- `ctr` (NUMERIC)
- `avg_position` (NUMERIC)
- `cache_date` (DATE)
- `created_at` (TIMESTAMP)

**RLS Policies:**

- Users can only view, insert, and update their own session data
- Users can only view and insert their own chat messages
- All tables have Row Level Security enabled

### **9.2 Audit Rules**

The current implementation includes:

**SEO Score Calculation:**

```python
seo_score = min(100, max(0, (total_clicks * 10) + (50 - avg_position) * 2))

```

**Date Range Detection:**

- Default: Last 30 days
- Custom ranges: last week (7 days), last month (30 days), last 3 months (90 days), last 6 months (180 days), last year (365 days), yesterday, today, last 7/14/60/90 days

**Caching Strategy:**

- Default 30-day range: Check cache first, fetch from GSC if not cached
- Custom date ranges: Always fetch fresh data from GSC API
- Cache expires daily (cache_date = today)

### **9.3 API Endpoints**

**Authentication:**

- `GET /auth/google/authorize` - Generate Google OAuth authorization URL
- `GET /auth/google/callback` - Handle OAuth callback and token exchange
- `POST /auth/logout` - Logout user and deactivate session
- `GET /auth/me` - Get current user information

**GSC Integration:**

- `GET /auth/gsc/properties` - Get user's Google Search Console properties
- `POST /auth/gsc/select-property` - Select a GSC property for the user
- `GET /auth/gsc/selected-website` - Get user's selected website
- `GET /auth/gsc/metrics` - Get GSC metrics with caching support

**Chat/AI Features:**

- `POST /auth/chat/send` - Send chat message and get AI response
- `GET /auth/chat/history` - Get chat history for current user

**UI Routes:**

- `GET /` - Root endpoint with API info
- `GET /ui` - Serve main UI
- `GET /dashboard` - Serve dashboard
- `GET /login` - Serve login page
- `GET /settings` - Serve settings page
- `GET /health` - Health check endpoint

### **9.4 SEO Score Formula**

Current implementation uses a simplified formula:

```python
seo_score = min(100, max(0, (total_clicks * 10) + (50 - avg_position) * 2))

```

**Metrics Available:**

- **SEO Score**: 0-100 scale based on clicks and position
- **Organic Traffic**: Total impressions from GSC
- **Clicks**: Actual click count from GSC
- **CTR**: Click-through rate (clicks/impressions * 100)
- **Average Position**: Average ranking position

### **9.5 AI Agent System**

**Solvia (Main Agent):**

- Provides SEO health overview
- Interprets GSC metrics in plain English
- Focuses on actionable insights and business impact

### **9.6 QA Checklist**

- **OAuth Flow Testing**
    - Google OAuth authorization URL generation
    - Token exchange and user session storage
    - GSC property retrieval and selection
    - Token refresh handling
- **GSC Integration Testing**
    - API quota management and error handling
    - Data caching for performance
    - Custom date range support
    - Metrics calculation accuracy
- **Security Testing**
    - Row Level Security (RLS) enforcement
    - JWT token validation
    - User session isolation
    - API endpoint authorization
- **Performance Testing**
    - GSC API response times
    - Database query performance
    - AI response generation speed
    - Static file serving
- **Data Accuracy Testing**
    - GSC metrics validation against Google's data
    - SEO score calculation consistency
    - Date range detection accuracy
    - Cache invalidation logic

### 9.7 Figma Prototype

https://www.figma.com/design/yLu0BWJlPq5TfXUJr1LMHu/solvia-product?node-id=122-1623&t=rhWfuck6kvHLMo2c-1

Interactive prototype: https://www.figma.com/proto/yLu0BWJlPq5TfXUJr1LMHu/solvia-product?page-id=0%3A1&node-id=122-1623&viewport=-775%2C1044%2C0.55&t=M7zG0MY212hFldCy-1&scaling=scale-down&content-scaling=fixed&starting-point-node-id=128%3A793&show-proto-sidebar=1